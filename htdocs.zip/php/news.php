<article>

<h1>Latest News</h1>

<h5 class="font-weight-bold">End of Week 1</h5>
<h6>May 10, 2019</h6>
<p>Start of Phase 1<br />

<h5 class="font-weight-bold">End of Week 2</h5>
<h6>May 17st, 2019</h6>
<p>Phase 1 in Progress<br />

<h5 class="font-weight-bold">End of Week 3</h5>
<h6>May 24st, 2019</h6>
<p>Phase 1 in Progress<br />

<h5 class="font-weight-bold">End of Week 4</h5>
<h6 >May 31, 2014</h6>
<p>Phase 1 in Progress<br /> 

<h5 class="font-weight-bold">End of Week 5</h5>
<h6>June 7, 2019</h6>
<p>Assignment #1 Completion / Phase 1 Completed</p><br />

</article>