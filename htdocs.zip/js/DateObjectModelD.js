var today = new Date(); //new Date() object with current date and time
var year0 = today.getFullYear();

var ft0 = document.getElementById('foot0');
ft0.innerHTML = '<p>Copyright &copy Damian ' + year0 + '</p>';


var today1 = new Date(); //new Date() object with current date and time
var year1 = today.getFullYear();

var ft1 = document.getElementById('foot1');
ft1.innerHTML = '<p>Copyright &copy Robert ' + year1 + '</p>';

var today1 = new Date(); //new Date() object with current date and time

var year2 = today.getFullYear();
var ft2 = document.getElementById('foot2');
ft2.innerHTML = '<p>Copyright &copy Steve ' + year2 + '</p>';

var year3 = today.getFullYear();
var ft3 = document.getElementById('foot3');
ft3.innerHTML = '<p>Copyright &copy Thomas ' + year3 + '</p>';
