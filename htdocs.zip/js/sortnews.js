// Source: https://www.w3schools.com/howto/howto_js_sort_list.asp
// Source: http://www.matthiassommer.it/programming/web/javascript/alphabetical-list-navigation-with-javascript-html-and-css/
